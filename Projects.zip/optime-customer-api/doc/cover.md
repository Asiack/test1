![](manual_images/media/cover.jpg){width="8.25in" height="11.693334426946631in"}



> **Imprint**

Schaeffler Monitoring Services GmbH

Kaiserstraße 100

52134 Herzogenrath

Germany

Telephone: +49 (0) 2407 9149 66

Fax: +49 (0) 2407 9149 59

Email: industrial-services@schaeffler.com 

Website: www.schaeffler.com/services

All rights reserved.

No part of the documentation or software may be reproduced in any form
or processed, duplicated or distributed using electronic systems without
our written consent. We would like to point out that the designations
and brand names of the various companies used in the documentation are
generally protected by trademark, brand and patent laws.

Microsoft, Windows and Microsoft Edge are brands or registered
trademarks of the Microsoft Corporation in the USA and/or in other
countries. Google Chrome™ is a trademark of Google. Postman is a
trademark of Postman Inc.

Version 1.4.1

© 3/31/2022 - Schaeffler Monitoring Services GmbH
