---

typora-root-url: images
---

[TOC]



# 1. General

## 1.1. About this guide

This guide describes the general characteristics of the Schaeffler
OPTIME Customer API. This includes instructions of how to access the
Schaeffler Developer Portal and how to set credentials for the
machine-to-machine integration of the OPTIME Customer API. Finally, you
will find detailed information about the individual calls as well as the
returned data.

**This document is provided as is and is only available in English.**



<u>**Further information**</u>

Schaeffler OPTIME Customer API is part of the award-winning OPTIME
solution, a comprehensive condition monitoring system that offers simple
plug & play installation, and works on many machines. OPTIME features
can detect potential damage in a very early stage and they support you
in planning, for example, long-term maintenance or spare-parts
requirements. For more details refer to
www.schaeffler.com/optime.

<u>**Definitions**</u>

* Product: The OPTIME Customer API described in this
  manual.
* User: Person or organisation capable of putting the product into
  operation and using it. The user should be a key user / developer with
  fundamental knowledge about REST APIs as well as common processes and
  tools (e.g. Postman) used in this environment.

<u>**Symbols used**</u>

> :bulb: This symbol indicates
>
> * helpful additional information and 
> * device settings or practical tips that will help you to perform activities more efficiently.


## 1.2. Abbreviations

We use the following abbreviations in this document:

| Abbreviation | Description                                  |
|--------------|----------------------------------------------|
| API          | Application Programming Interface            |
| AppKey       | Application Key                              |
| CASS         | Consumer Application Self Service            |
| CM           | Condition Monitoring                         |
| DC           | Direct Current                               |
| HTTPS        | Hypertext Transfer Protocol Secure           |
| ID           | Identifier                                   |
| JSON         | JavaScript Object Notation                   |
| KPI          | Key Performance Indicator                    |
| OAuth2       | Industry-standard protocol for authorization |
| REST         | Representational State Transfer              |
| UTC          | Coordinated Universal Time                   |
| X-APIKEY     | Application Key                              |



# 2. API description

The Schaeffler OPTIME Customer API is designed for clients who want to
transfer the most important information from Schaeffler OPTIME System to
their own higher-level system. Information that is made available via
OPTIME Customer API includes raw data and KPIs from the sensors as well
as identified machine conditions and alarm developments from digital
Schaeffler analytic services.

The following sections offer a detailed description of the API:

* Access to the Schaeffler OPTIME Customer API
* URL
* Timestamp
* Response limitations
* Measurement data


> :bulb: Schaeffler OPTIME Customer API does not give access to all information details. 
> Please use OPTIME System for unavailable information.



## 2.1. Access to the Schaeffler OPTIME Customer API

Schaeffler provides an accessing process for API products in general.
This process is also in use for Schaeffler OPTIME Customer API:

![](./manual_images/media/image2.png){width="5.243758748906386in"
height="3.2202121609798775in"}

The basic steps for accessing Schaeffler OPTIME Customer API are
described in the following sections:

* Registering with the Schaeffler Developer Portal
* Setting up the API application
* Setting up the API authorization

### 2.1.1. Registering with the Schaeffler Developer Portal

Proceed as follows to register with the Schaeffler Developer Portal as a key user / developer:

1. Send an email to request an invitation to the Schaeffler Guest network.
   The email needs to contain a short explanation of why you need the access. Use the following email address: cm_api_onboarding@schaeffler.com
2. After the approval of the request, you will receive an email with the invitation to the Schaeffler Guest network.
3. Follow the instructions to generate your credentials.
4. Use one of the following links to access the corresponding version of the Schaeffler Developer Portal. You will need the credentials from
   step 3 for the access:
   - **Sandbox and Sandbox (legacy)**: https://developer-qas.schaeffler.com
   - **Production system**: https://developer.schaeffler.com
5. You need to register for each URL separately. Test system and production system are fully separate.
6. In the Developer Portal, click the button **Sign Up** and fill up
the form with the required information. It usually takes one workday to
get the access granted.
7. You can log in the Schaeffler Developer Portal with your
credentials.
In the next steps, we will guide you in setting up the API application
and accessing it with the application credentials.

### 2.1.2. Setting up the API authorization


Access to the OPTIME Customer API is granted by OAuth2 credentials. In
the portal, navigate to the the area *Manage* and click on the button
Application Manager (this will open the link
https://developer.schaeffler.com/cass).

![Graphical user interface, website Description automatically
generated](./manual_images/media/image3.png){width="4.483919510061242in"
height="4.369043088363955in"}

1.  You will land on *Your Applications* form, click on the CREATE
    button.

2.  In the pop-up window *Create New Application* choose an Application
    Name, the Environment PRODUCTION and the Permission Model
    APPLICATION.

![Graphical user interface, text, application Description automatically
generated](./manual_images/media/image5.png){width="4.180555555555555in"
height="2.763888888888889in"}


3. After clicking on CREATE, the application is generated, and shown in
    Your Applications.

4. By clicking in the application just created you are redirected to
    the *Application Details* screen. For your application to work, you
    need the following

    a.  Use the "CASS Application ID", as a ClientID for bearer token
        generation in the OAuth2 context.

    b.  Generate a new secret under the "Secrets" section. It will be
        displayed exactly one time, so make sure to securely store it.
        If it gets lost, you cannot retrieve it again, but you can
        generate a new one.

    c.  For now, there is no need to use other functions here. A nice
        option is to share this application with other "Owners" from
        your developer group for easier collaboration. Each owner needs
        to have a Schaeffler Account or Guest account to be invited
        here.

![Graphical user interface, text, application, email Description
automatically
generated](./manual_images/media/image7.png){width="6.0932239720035in"
height="3.885524934383202in"}

5. Now you can start to generate bearer token for authenticate API
    calls by using the CASS Application ID as a ClientID in conjunction
    with the secret and the right scope. The token provider for our APIs
    has this url: <https://login.microsoftonline.com/67416604-6509-4014-9859-45e709f53d3f/oauth2/v2.0/token>

> :bulb: The necessary scopes to be used are these:
>
> Sandbox: api://optime-customer-api-qas/.default
>
> Production: api://optime-customer-api-prd/.default

6. Send the newly generated **CASS Application ID** to the following
    email address:\
    <cm_api_onboarding@schaeffler.com>

With this procedure, your API account will be verified and linked to the
appropriate OPTIME enterprise. Only after this procedure the API will be
able to provide data from you OPTIME sensors!

### 2.1.3. Setting up the API application

After setting up the basic API application with all credentials, you
must configure your application by finally adding the specific APIs you
want to use within that application.

For this, proceed as follows.
1. After the successful registration, access the Schaeffler Developer Portal 
with one of the following links:
> :bulb: 
> **Sandbox**
> <https://developer-qas.schaeffler.com>
>
> **Production system**
> <https://developer.schaeffler.com>

2. In the search query type **OPTIME** to see the API list.

3. Click **Schaeffler OPTIME Customer API** and you will be redirect to
the landing page (at the link:
https://developer.schaeffler.com/product-catalog/schaeffler-optime/schaeffler-optime-customer-api)

4. Click the button **Subscribe**.

5. You will be asked whether the API subscription shall be added to a
new application or whether it shall be added to an existing application.
Click on *Flip me!* and then the **Add to existing application** form
will appear.

6. In the **Add to existing application** dialog, you will find your
API application, that you created in the previous steps. Please select
it and continue by clicking **Add**.

7. Your application is now ready! You can always see all your
applications in the application manager
(<https://developer.schaeffler.com/cass>).

> :bulb:
> 
> In an older version of this API, you needed to use the Application
> ID also as an X-APIKEY. This procedure is completely obsolete after
> credential generation with the new* *API Portal!*
> 
> Existing credentials and integrations can still be used until they run
> out of their validity time frame.

### 2.1.4. SWAGGER/OPENAPI Specifications

The API portal give access to the specification of the OPTIME Customer
API, as well as an integrated Swagger editor for the API documentation.
To download the specifications:

1.  Go the **Schaeffler OPTIME Customer API** as described before and
    click on the tab *Reference Documentation.*

2.  Click on Download OPENAPI SPECIFICATION button to get the
    specification in yaml format.

![Graphical user interface, application, website Description
automatically
generated](./manual_images/media/image13.png){width="6.668055555555555in"
height="3.303472222222222in"}

As some API client, for example postman, can import API specifications
in JSON format as collections, there is also the possibility to get the
JSON file from the Application Manager. To this aim:

1.  Navigate to the application manager as previously described.

2.  Select your OPTIME application

3.  Open the *Subscribed Product section* and click on the green swagger
    icon.

![Graphical user interface, text, application, email Description
automatically
generated](./manual_images/media/image14.png){width="5.52049321959755in"
height="3.244503499562555in"}

## 2.2. URL

Depending on your environment, you can use the following URLs for API calls:
> :bulb:
> **API Sandbox:** <https://api-qas.schaeffler.com:443/rest/cm/optime/v1>
> **API Production system:** <https://api.schaeffler.com:443/rest/cm/optime/v1>

Each call must contain the authorization information as described in the
section Setting up the API authorization.

For available **\<call\>** commands refer to the section API calls and
data structures. In some cases, we might indicate to the Customer to try
the API via connection to a **Legacy Sandbox**, which does not require
OAuth2 authorization, but only authentication via username and password,
and give access to test data:

> **Legacy API Sandbox**: <https://api-qas.schaeffler.com:443/rest/cm/optime/v0>

## 2.3. Timestamp

All timestamp values called `ts` must be set or interpreted as microseconds and UNIX timestamp format. All other timestamp values like `starttime` or `endtime` must be set or interpreted as milliseconds.

## 2.4. Response limitations

For calls with a result size of more than 5 MB the API will return the status code `500 error`. In such a case, you need to fetch the data in smaller batches. In a future API update, we will add paging functionality.

## 2.5. Measurement data

Refer to the following sections for details on the measurement data that the system returns for KPI and raw vibration data calls.

### 2.5.1. KPI descriptions

The Schaeffler OPTIME measurement KPIs collected from a Schaeffler
OPTIME vibration sensor are summarized in the table below:

| **Data tag**    | **KPI**                     | **Description**                                              |
| --------------- | --------------------------- | ------------------------------------------------------------ |
| **ISO**         | ISO (mm/s)                  | Indicates standardized vibration  severity (ISO 10816 / ISO 20816). |
| **DeMod**       | Demodulation (m/s2)         | Demodulation value to detect  impacting (preferred value for bearings). |
| **RMS high**    | RMS upper band (m/s2)       | Root mean square upper band, acceleration  (750 Hz – max frequency) to detect bearings failure. |
| **RMS low**     | RMS lower band (m/s2)       | Root mean square lower band,  acceleration (2 Hz – 750 Hz) to detect indications of imbalance and  misalignment. |
| **Kh**          | Excess kurtosis high        | Excess kurtosis high (750 Hz –  max frequency) to detect impacting (bearings, gears), used to characterize  the pulse character of a vibration signal so value is raising when a lot of  peaks are present in the signal. |
| **Kl**          | Excess kurtosis low         | Excess kurtosis low (2 Hz – 750  Hz) to detect impacting (looseness), used to characterize the pulse character  of a vibration signal so value is raising when a lot of peaks are present in  the signal. |
| **Temp**        | Temperature (°C)            | Temperature of the measuring  point in Celsius, to detect an increase in temperature for bearings and  lubricant - mainly by monitoring the trend. |
| **Vibration_X** | Raw data from    x-axis (g) | Raw vibration acceleration data  measured in x-axis direction. |
| **Vibration_Y** | Raw data from    y-axis (g) | Raw vibration acceleration data  measured in y-axis direction. This is the default measuring direction along  the screw of the sensor.  **Typically, raw data  only exists for this direction.** |
| **Vibration_Z** | Raw data from    z-axis (g) | Raw vibration acceleration data  measured in z-axis direction. |



### 2.5.2. Raw vibration data description

The raw vibration data is stored as a JSON document to a data tag and is
provided in the same structure via the API. The JSON structure contains
the following header fields:

| **Header field** | **Description**                                              |
| ---------------- | ------------------------------------------------------------ |
| **axis**         | Defines the measurement axis: <br />**0** = x-axis  <br />**1** = y-axis  <br />**2** = z-axis |
| **type**         | Defines the type of the sensor:  <br />**1** = OPTIME AW-3 sensor  <br />**2** = OPTIME AW-5 sensor |
| **scale**        | Defines full scaling for OPTIME  sensor’s accelerometer that is used for vibration data sample:  <br />**0** = ±2 g  <br />**1** = ±4 g  <br />**2** = ±8 g  <br />**3** = ±16 g |
| **speedHz**      | Defines the machine speed in Hz.  <br />This header field is only  available if the sensor can measure the machine speed. It is not provided by  OPTIME sensors. |
| **samplingRate** | Defines the sampling rate in Hz.  For OPTIME sensors, this is  calculated on the basis of the sensor type and data length:  <br />**OPTIME AW-3:** Data length is 1 seconds  <br />**OPTIME AW-5:** Data length is 3 seconds |
| **uuid**         | Defines the unique identifier  for the individual measurement.   <br />This identifier is used  internally by the OPTIME system to distinguish different raw data  measurements when analyzing them with Schaeffler Analytics services. |
| **ts**           | Defines the timestamp of the measurement.  <br />**Timestamp format:** Unix UTC time in microseconds. |
| **data**         | Defines the actual raw vibration  data samples with the following values: <br /> - Int16 integers  <br /> - Value range from -32,768 to +32,767  <br /> - Dynamical scaling in each measurement. Refer to the header field **scale**  for the used scaling. <br /> - Value contains the DC offset element. By default, raw data is  therefore not de-normalized to 0 g-level. |

As example, by calling the endpoint */measurement_point/{id}/vibration_data* one obtains:

```json
{
  "name": "Vibration_Y",
  "unit": null,
  "values": [
        {
          "ts": 1642161608000000,
          "v": {
            "axis": 1,
            "type": 2,
            "scale": 0,
            "uuid": "3b16b0e3-d063-480f-84c7-1844fb86ac56",
            "ts": 1642161608000,
            "data": [
              -855,-968, -911, ..., -745
            ]
          }        
        }
  ]
}

```
> :bulb:
> Please be aware that the old endpoint:
> */measurement_point/{id}/vibration_raw* gives a differently formatted response, and it is deprecated.


## 2.5.3. Alarm type data description

**Alarm key attribute response values**
Refer to the following table for alarm key attributes:

| **Group**                                                    | **Description**                                              | **Type**       | **Severity** | **Availability in release** |
| ------------------------------------------------------------ | ------------------------------------------------------------ | -------------- | ------------ | --------------------------- |
| ISO absolute pre-alarm                                       | ISO value over absolute  pre-limit                           | WARNING        | HIGH         | R3 PI1                      |
| ISO absolute main alarm                                      | ISO value over absolute main  limit                          | ALARM          | CRITICAL     | R3 PI1                      |
| ISO pre-alarm                                                | ISO value over pre-limit                                     | WARNING        | HIGH         | R3 PI1                      |
| ISO alarm                                                    | ISO value over main limit                                    | ALARM          | CRITICAL     | R3 PI1                      |
| DeMod pre-alarm                                              | DeMod value over pre-limit                                   | WARNING        | HIGH         | R3 PI1                      |
| DeMod alarm                                                  | DeMod value over main limit                                  | ALARM          | CRITICAL     | R3 PI1                      |
| RMSh pre-alarm                                               | RMSh value over pre-limit                                    | WARNING        | HIGH         | R3 PI1                      |
| RMSh alarm                                                   | RMSh value over main limit                                   | ALARM          | CRITICAL     | R3 PI1                      |
| RMSl pre-alarm                                               | RMSl value over pre-limit                                    | WARNING        | HIGH         | R3 PI1                      |
| RMSl alarm                                                   | RMSl value over main limit                                   | ALARM          | CRITICAL     | R3 PI1                      |
| Temp absolute alarm                                          | Temp absolute alarm                                          | ALARM          | CRITICAL     | R3 PI1                      |
| Temp pre-alarm                                               | Temp value over pre-limit                                    | WARNING        | HIGH         | R3 PI1                      |
| Temp alarm                                                   | Temp value over main limit                                   | ALARM          | CRITICAL     | R3 PI1                      |
| Battery low                                                  | Battery level is low                                         | WARNING        | NORMAL       | R3 PI1                      |
| Data not received                                            | Data not received in 24 hours!                               | WARNING        | NORMAL       | R3 PI1                      |
| Collective E-motor bearing  damage or lubrication problem    | Probably bearing damage or  lubrication problem              | Probable cause | HIGH*        | R3 PI1                      |
| Collective E-motor bearing  damage problem                   | Probably bearing damage problem                              | Probable cause | HIGH*        | R3 PI1                      |
| Collective E-motor  imbalance/misalignment or bearing damage problem | Probably imbalance/misalignment  or bearing damage problem   | Probable cause | HIGH*        | R3 PI1                      |
| Collective E-motor  imbalance/misalignment problem           | Probably imbalance/misalignment  problem                     | Probable cause | HIGH*        | R3 PI1                      |
| Collective E-motor lubrication  problem                      | Probably lubrication problem                                 | Probable cause | HIGH*        | R3 PI1                      |
| Collective Fan or Compressor  bearing damage or lubrication problem | Probably bearing damage or lubrication  problem              | Probable cause | HIGH*        | R3 PI1                      |
| Collective Fan or Compressor  bearing damage problem         | Probably bearing damage problem                              | Probable cause | HIGH*        | R3 PI1                      |
| Collective Fan or Compressor  blade, imbalance/misalignment or bearing damage problem | Probably blade,  imbalance/misalignment or bearing damage problem | Probable cause | HIGH*        | R3 PI1                      |
| Collective Fan or Compressor  imbalance/misalignment problem | Probably imbalance/misalignment  problem                     | Probable cause | HIGH*        | R3 PI1                      |
| Collective Fan or Compressor  lubrication problem            | Probably lubrication problem                                 | Probable cause | HIGH*        | R3 PI1                      |
| Collective Gearbox gear damage  or bearing damage problem    | Probably gear damage or bearing  damage problem              | Probable cause | HIGH*        | R3 PI1                      |
| Collective Pump bearing damage  or cavitation problem        | Probably bearing damage or  cavitation problem               | Probable cause | HIGH*        | R3 PI1                      |
| Collective Pump bearing damage,  lubrication or cavitation problem | Probably bearing damage,  lubrication or cavitation problem  | Probable cause | HIGH*        | R3 PI1                      |
| Collective Pump  imbalance/misalignment problem              | Probably imbalance/misalignment  problem                     | Probable cause | HIGH*        | R3 PI1                      |
| Collective Pump lubrication  problem                         | Probably lubrication problem                                 | Probable cause | HIGH*        | R3 PI1                      |
| Collective Pump vane, imbalance/misalignment,  bearing damage or cavitation problem | Probably vane,  imbalance/misalignment, bearing damage or cavitation problem | Probable cause | HIGH*        | R3 PI1                      |
| Machine status suspect                                       | Machine status is suspect!                                   | WARNING        | LOW          | R3 PI2                      |
| Machine status pre-warning                                   | Machine status is warning!                                   | WARNING        | HIGH         | R3 PI2                      |
| Machine status warning                                       | Machine status is warning                                    | ALARM          | HIGH         | R3 PI2                      |
| Machine status severe                                        | Machine status is severe!                                    | ALARM          | CRITICAL     | R3 PI1                      |

\* CRITICAL may exist for old probable causes

# 4. Overview of data structures and their dependencies

Refer to the following sections for details on data structures and their dependencies.

## 4.1. Machine level structures

![](./manual_images/media/image15.png){width="6.448833114610673in"
height="2.986111111111111in"}

## 4.2. Sensor / Measurement point level structures

![](./manual_images/media/image16.png){width="6.131944444444445in"
height="2.8518547681539808in"}

## 4.3. Link a specific alarm to the corresponding sensor and KPI trend

![](./manual_images/media/image17.png){width="6.972222222222222in"
height="3.0694444444444446in"}

# 5. Status codes of REST API

The status codes referring to the REST API are defined in the REST
standard. Refer to the following table for details on each status code:

| **HTTP Status Code**           | **Description**                                              |
| ------------------------------ | ------------------------------------------------------------ |
| **200 OK**                     | This status code indicates that  the REST API successfully carried out whatever action the client requested. |
| **201 Created**                | This status code is sent out  whenever a resource is created inside a collection. |
| **204 No Content**             | This status code is usually sent  out in response to a PUT, POST, or DELETE request when the REST API declines  to send back any status message or representation in the response message’s  body. |
| **400 Bad Request**            | This status code is the generic  client-side error status. It indicates, for example an invalid input  parameter or that no query result could be generated. |
| **401 Unauthorized**           | This status code indicates that  the client tried to operate on a protected resource without providing the  proper authorization.  This is the case when the client  entered an invalid Auth token. The client should refresh the token and then  try again. |
| **403 Forbidden**              | This status code indicates that  the client’s request is formed correctly, but that the operation is blocked  because of a forbidden request. |
| **404 Not Found**              | This status code indicates that  the REST API can’t map the client’s URI to a resource.  The resource was not found. |
| **405 Method Not  Allowed**    | This status code indicates that  the resource doesn't support the specified HTTP verb/method. |
| **409 Conflict**               | This status code indicates that  the request could not be completed due to a conflict with the current state  of the resource. |
| **411 Length Required**        | This status code indicates that  the server refuses to accept the request without a defined Content Length  header. |
| **412 Precondition  Failed**   | This status code is sent when  the client has indicated preconditions in its headers which the server does  not meet.   The status can also occur when there are problems on the secure token side. |
| **429 Too Many  Requests**     | This status code indicates that  the user has sent too many requests in a given amount of time (rate  limiting). |
| **500 Internal Server  Error** | This status code is the generic  REST API error response. Servers are not working as expected. The request is  probably valid but needs to be requested again later.   The status can also occur when the data limit has been exceeded: Response  size >5 MB. |
| **503 Service  Unavailable**   | This status code indicates that  the server is not ready to handle the request. |



# 6. Contact / Support

## **Manufacturer**
**Schaeffler Monitoring Services GmbH**</br>
Kaiserstraße 100</br>
52134 Herzogenrath</br>
Germany</br>

Tel.: +49 2407 9149-66</br>
Fax: +49 2407 9149-59

Internet: www.schaeffler.com/en/services</br>
Further information: www.schaeffler.com/optime</br>
Contact: industrial-services@schaeffler.com</br></br>

Please send all correspondence directly to Schaeffler Monitoring Services GmbH!

A subsidiary of</br>
**Schaeffler Technologies AG & Co. KG**</br>
PO Box 1260</br>
97419 Schweinfurt</br>
Germany

Georg-Schäfer-Straße 30</br>
97421 Schweinfurt</br>
Germany</br></br>

All rights reserved.</br>
No part of the documentation or software may be reproduced in any form or processed, duplicated or distributed using
electronic systems without our written consent. We would like to point out that the designations and brand names of the
various companies used in the documentation are generally protected by trademark, brand and patent laws.</br>
Microsoft, Windows and Microsoft Edge are brands or registered trademarks of the Microsoft Corporation in the USA and/or in
other countries. Google Chrome™ is a trademark of Google. Postman is a trademark of Postman Inc.</br></br>

## **Support**
For information on technical support, go to www.schaeffler.de/en/technical-support.
