# v1.3.0

### New features

* Schema: VibrationData
  * add property: **dcOffset**
* Schema: LubricatorInfo
  * add properties: **lubricantType**, **materialDesignation**, **batteryVoltage**
    and **outletAverageCurrent**
* Schema: SensorInfo
  * add properties: **sensorMeasurementMode** and **nonContinuousModeInfo**

### Bugfixes of documentation


# v1.2.0

### New features

* Schema: MachineItemDTO
  * add properties: **criticality**, **isoClass**, **type**, **machineId**
* Schema: SensorInfo
  * add properties: **learningMode**, **installationPosition**, **deviceType**, **deviceSpeedRange**, **deviceSpeed**,
    **deviceMinSpeed**, **bearingType**, **bearingManufacturer**

### Bugfixes of documentation

* Schema: SensorInfo
  * add missing property **sensorIsNDE** that was added to API in v1.1. 
  Property is deprecated and **installationPosition** should be used instead.
* Schema: EventNotificationJSON
  * add missing property **kpiName** that was added to API in v1.1
* Schema: VibrationValueDTO
  * add `nullable = true` to **unit** and **values**.
* Schema: DeprecatedVibrationValueDTO
  * add `nullable = true` to **unit** and **values**.
  * add properties **al** and **pal** that were added already in earlier release.
* Schema: DatanodeValueDTO
  * add `nullable = true` to **unit**.

# v1.1.1

* /machine/{id}/alarms-ack
    * moved events object from request query parameters to request body
    * fixed response from array of AlertAckResponse object to single AlertAckResponse object
* Schema: LubricatorInfo
    * outletStatus property type changed from int32 to '#/components/schemas/LubricatorStatus'
* Schema: ResourceDTO (used in response of /resource-tree/{id})
    * add property **type**
* Schema: DeprecatedVibrationValue
    * change title so there wound be duplicated schemas anymore
* Schema: DeprecatedVibrationValueDTO
    * change title so there wound be duplicated schemas anymore
* all response bodies are application/json beside /ping that is text/plain
* Added new tags for visualization purpose
