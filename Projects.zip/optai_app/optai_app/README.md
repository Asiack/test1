# optai_app
Repo for the code to be developed in the OPTIME AI CORE II Hackathon
