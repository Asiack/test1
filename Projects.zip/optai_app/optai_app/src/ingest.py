import requests
import pandas as pd
import toml
from pathlib import Path
from datetime import datetime, timedelta


class DataFetch:

    def __init__(self, eid='E50'):
        self.eid = eid
        self._token = None
        self._token_expiration = None
        self.base_url = 'https://api.schaeffler.com:443/rest/cm/optime/v1'

    def _token_expired(self):
        if (not self._token_expiration) or (not self._token):
            return True
        elif self._token_expiration <= datetime.now():
            return True
        else:
            return False

    def get_token(self):
        if self._token_expired:
            secrets = toml.load(Path.home() / '.cass/secrets.toml')

            tenant_id = '67416604-6509-4014-9859-45e709f53d3f'
            token_url = f'https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token'
            application_id = secrets['prod']['application_id']
            application_secret = secrets['prod']['application_secret']
            scope = 'api://optime-customer-api-prd/.default'
            params = {
                "grant_type": "client_credentials",
                "client_id": application_id,
                "client_secret": application_secret,
                "scope": scope,
                "Accept": "*/*",
                "Accept-Encoding": "gzip, deflate, br"}

            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }

            token = requests.request("POST",
                                     url=token_url,
                                     headers=headers,
                                     data=params)
            expires_in = token.json()['expires_in']
            expires_at = datetime.now() + timedelta(seconds=token.json()['expires_in']) - timedelta(seconds=30)
            self._token = token.json()['access_token']
            self._token_expiration = expires_at
        return

    def get_resources(self, resources):
        self.get_token()
        url = self.base_url + f"/{resources}?eid={self.eid}"
        payload = {}
        headers = {
            'Authorization': 'Bearer ' + self._token
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        return pd.DataFrame(response.json())

